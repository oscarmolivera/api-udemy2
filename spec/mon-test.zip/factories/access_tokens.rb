FactoryBot.define do
  factory :access_token do
    token { "MyString" }
    user { nil }
  end
end
